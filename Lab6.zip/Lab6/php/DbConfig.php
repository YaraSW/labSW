<?php
$local=1; //0 para la nube
if ($local==1){
    $server="localhost";
    $user="root";
    $pass="";
    $basededatos="quiz";
}
else{
    $server="localhost";
    $user="";
    $pass="";
    $basededatos="";
}
?>
