<div id='page-wrap'>
<header class='main' id='h1'>
  <span class="right"><a href="SignUp.php">Registro</a></span>
        <span class="right"><a href="Login.php">Login</a></span>
        <span class="right" style="display:none;"><a href="/logout">Logout</a></span>

</header>
<nav class='main' id='n1' role='navigation'>
  <span><a href='Layout.php'>Inicio</a></span>
  <span><a href='QuestionFormWithImage.php'> Insertar Pregunta</a></span>
  <span><a href='ShowQuestions.php'> Ver pregunta</a></span>
  <span><a href='ShowXmlQuestions.php'> Ver preguntas XML</a></span>
  <span><a href='Credits.php'>Creditos</a></span>
</nav>


